
import React, { Component } from 'react';
import Navbar from './Navbar';

export const MyContext = React.createContext();
class App extends Component {
  componentDidMount() {
    fetch('https://jsonplaceholder.typicode.com/posts')
      .then(response => response.json())
      .then(json => {
        //console.log(json)
        this.setState({
          posts: json
        })
      })
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(response => response.json())
      .then(json => {
        //console.log(json)
        this.setState({
          users: json
        })

      })
    fetch('https://jsonplaceholder.typicode.com/todos')
      .then(response => response.json())
      .then(json => {
        //console.log(json)
        this.setState({
          todos: json
        })
      })
  }

  render() {
    return (
      <MyContext.Provider value={{
        state: this.state

      }}>
        <Navbar />
      </MyContext.Provider>
    );
  }
}

export default App;

