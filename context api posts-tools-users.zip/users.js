import React, { Component } from 'react'
import { MyContext } from './App';
class Users extends Component {
    constructor() {
        super();
        this.state = {
            flag: true,
            data: []
        }
    }
    getUsers(data) {
        const users = data.map(
            (user, index) =>
                <div className="card mb-2" key={index}>
                    <div className="card-body">
                        <div className="d-flex justify-content-between">
                            <h5 className="card-title text-dark font-weight-bold">{user.name}</h5>
                        </div>
                        <hr></hr>
                        <p className="card-text">{user.id}</p>
                        <p className="card-text">{user.username}</p>
                        <p className="card-text">{user.email}</p>
                    </div>

                </div>
        )
        return users

    }

    render() {
        return (
            <MyContext.Consumer>
                {(context) => (
                    <div>
                        <div className="container">
                            <div className="jumbotron py-3 my-4">
                                <p className="display-4 text-center mb-0">Users</p>

                            </div>
                            <div className=" form-group mt-2 mb-2">

                                <div className="form-group">
                                    {this.getUsers(context.state.users)}

                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </MyContext.Consumer>

        );
    }
}

export default Users;

