
import React, { Component } from 'react'
import { MyContext } from './App';

class Posts extends Component {



    constructor() {
        super();

        this.state = {
            flag: true,
            dataCards: []

        }

    }

    getCards(posts) {

        const dataCards = posts.map(
            (posts, index) =>
                <div className="card mb-2" key={index}>
                    <div className="card-body">
                        <div className="d-flex justify-content-between">
                            <h5 className="card-title text-dark font-weight-bold">
                                {posts.title}
                            </h5>

                        </div>
                        <hr></hr>
                        <p className="card-text">{posts.body}</p>
                        <footer className="blockquote-footer text-muted"><cite title="Source Title">Posted by: {posts.userId}</cite></footer>

                    </div>

                </div>
        )
        return dataCards

    }

    render() {
        return (
            <MyContext.Consumer>
                {(context) => (


                    <div>

                        <div className="container">
                            <div className="jumbotron py-3 my-4">
                                <p className="display-4 text-center mb-0">Posts</p>

                            </div>
                            <div className=" form-group mt-2 mb-2">

                                <div className="form-group">
                                    {this.getCards(context.state.posts)}

                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </MyContext.Consumer>

        );
    }
}

export default Posts;

