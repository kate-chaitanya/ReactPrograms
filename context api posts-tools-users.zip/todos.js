import React, { Component } from 'react'
import { MyContext } from './App';
class Todos extends Component {
    constructor() {
        super();
        this.state = {
            flag: true,
            data: []

        }

    }

    getTodos(data) {
        const todos = data.map(
            (todo, index) =>
                <div className="card mb-2" key={index}>
                    <div>
                        <div>
                            <h5 className="card-title text-dark font-weight-bold">
                                {todo.title}
                            </h5>
                            <p className="card-text">Status:{(todo.completed) ? <p>Yes</p> : <p>No</p>}</p>
                            <div>
                                <footer className="blockquote-footer text-muted"> <cite title="Source Title">Posted by-{todo.userId}</cite></footer>
                            </div>

                        </div>
                        <hr></hr>

                    </div>

                </div>
        )
        return todos

    }

    render() {
        return (
            <MyContext.Consumer>
                {(context) => (
                    <div>
                        <div className="container">
                            <div className="jumbotron py-3 my-4">
                                <p className="display-4 text-center mb-0">Todos</p>

                            </div>
                            <div className=" form-group mt-2 mb-2">

                                <div className="form-group">
                                    {this.getTodos(context.state.todos)}

                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </MyContext.Consumer>

        );
    }
}

export default Todos;

