import React, { Component } from 'react';
import Users from './Users';
import Posts from './Posts';
import Todos from './Todos';

import {
    BrowserRouter as Router,
    Route,
    NavLink 
} from 'react-router-dom';

class Navbar extends Component {

    render() {
        return (
            <Router>
                    <nav className="navbar navbar-expand-lg navbar-dark bg-secondary">
                        <NavLink className="navbar-brand" to="/home" activeClassName="active">BulletinBoard</NavLink>                        
                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>

                        <div className="collapse navbar-collapse" id="navbarColor01">
                            <ul className="navbar-nav mr-auto">
                                <li className="nav-item">
                                    <NavLink className="nav-link" to="/Users" activeClassName="active">Users</NavLink>
                                </li>
                                <li className="nav-item">
                                    <NavLink className="nav-link" to="/Posts" activeClassName="active">Posts</NavLink>
                                </li>
                                <li className="nav-item">
                                    <NavLink className="nav-link" to="/Todos" activeClassName="active">Todos</NavLink>
                                </li>
                            </ul>
                        </div>
                    </nav>
                    <Route exact path="/Users" component={Users} />
                    <Route exact path="/Posts" component={Posts} />
                    <Route exact path="/Todos" component={Todos} />
            </Router>
        );
    }
}

export default Navbar;