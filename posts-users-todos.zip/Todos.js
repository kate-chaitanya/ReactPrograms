import React, { Component } from 'react'
class Todos extends Component {
    componentDidMount() {
        fetch('https://jsonplaceholder.typicode.com/todos')
            .then(response => response.json())
            .then(json => {
                this.setState({
                    toDo: json
                })
                console.log(this.state.toDo)
            })
    }
    constructor() {
        super();
        this.state = {
            flag: true,
            toDo: []
        }

    }
    gettoDos() {
        const toDos = this.state.toDo.map(
            (todo, index) => <div className="card mb-2" key={index}>
                <div className="card-body">
                    <div className="d-flex justify-content-between">
                        <h5 className="card-title text-primary font-weight-bold">UserId:{todo.userId}</h5>
                        <h5 className="card-body">Id:{todo.id}</h5>
                        <h5 className="card-body">Title:{todo.title}</h5>
                        <p className="card-body">{(todo.completed) ? <p>Completed: true</p> : <p>Completed: false</p>}</p>
                    </div>
                </div>
            </div>

        )

        return toDos
    }


    render() {
        return (
            <div className="container">
                <div className="jumbotron">
                    <p className="display-4 text-center mb-0">Todos</p>
                </div>
                {this.gettoDos()}
            </div>

        );
    }
}
export default Todos;

