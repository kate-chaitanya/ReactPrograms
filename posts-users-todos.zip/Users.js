import React, { Component } from 'react';

class Users extends Component {
    componentDidMount() {
        fetch('https://jsonplaceholder.typicode.com/users')
            .then(response => response.json())
            .then(json => {
                this.setState({
                    user: json
                })
                console.log(this.state.toDo)
            })
    }
    constructor() {
        super();
        this.state = {
            flag: true,
            user: []
        }

    }
    getUsers() {
        const users = this.state.user.map(
            (user, index) => <div className="card mb-2" key={index}>
                <div className="card-body">
                    <div className="d-flex justify-content-between">
                        <h5 className="card-title text-primary font-weight-bold">Id:{user.id}</h5>
                        <h5 className="card-body">Name:{user.name}</h5>
                        <h5 className="card-body">Email:{user.email}</h5>
                        
                    </div>
                </div>
            </div>

        )
        return users
    }


    render() {
        return (
            <div className="container">
            <div className="jumbotron">
              <p className="display-4 text-center mb-0">Users</p>
            </div>
            {this.getUsers()}
          </div>
            
        );
    }
}
export default Users;