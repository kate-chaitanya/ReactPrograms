import React, { Component } from 'react'
class Posts extends Component {
    componentDidMount() {
        fetch('https://jsonplaceholder.typicode.com/Posts')
            .then(response => response.json())
            .then(json => {
                this.setState({
                    posts: json
                })
                console.log(this.state.posts)
            })
    }
    constructor() {
        super();
        this.state = {
            flag: true,
            posts: []
        }

    }
    getPosts() {
        const posts = this.state.posts.map(
            (post, index) => <div className="card mb-2" key={index}>
                <div className="card-body">
                    <div className="d-flex justify-content-between">
                        <h5 className="card-title text-primary font-weight-bold">UserId:{post.userId}</h5>
                        <h5 className="card-body">Id:{post.id}</h5>
                        <h5 className="card-body">Title:{post.title}</h5>
                        <h5 className="card-body">Body:{post.body}</h5>
                        
                    </div>
                </div>
            </div>

        )

        return posts
    }


    render() {
        return (
            <div className="container">
                <div className="jumbotron">
                    <p className="display-4 text-center mb-0">Posts</p>
                </div>
                {this.getPosts()}
            </div>

        );
    }
}
export default Posts;

