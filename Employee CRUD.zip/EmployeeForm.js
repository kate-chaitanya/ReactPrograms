import React, { Component } from 'react';
import Employee from './model/Employee';
import axios from 'axios';

class EmployeeForm extends Component {

    employee

    componentDidMount() {
        this.employee = new Employee()
    }

    componentDidUpdate() {
        if (this.props.employee !== this.state.employee && this.props.employee !== undefined) {
            this.employee = this.props.employee
            this.setState({
                employee: this.props.employee
            })
        }
    }

    constructor() {
        super();
        this.employee = new Employee()
        this.state = {
            employee: this.employee,
            emailError: false,
            nameError: false,
            addressError: false,
            phonenumberError: false,
            numberValidationError: false,
            ageError: false,
            agelimitError: false,
            disabledFlag: true,
            successFlag: false
        }
    }

    handleSubmit(event) {
        event.preventDefault();
        if (this.props.employee === undefined)
            axios.post("http://localhost:8080/add", this.state.employee)
                .then(response => {
                    this.setState({
                        successFlag: (response.status === 200) ? true : false
                    })
                    this.employee = new Employee()
                    this.setState({ employee: this.employee })
                })

        else {
            axios.put("http://localhost:8080/save", this.state.employee)
                .then(response => {
                    this.setState({
                        successFlag: (response.status === 200) ? true : false
                    })
                    this.employee = new Employee()
                    this.setState({ employee: this.employee })
                })
        }
    }

    handleEmailChange(event) {
        this.employee.email = event.target.value
        this.setState({
            employee: this.employee,
            emailError: (this.employee.email === "") ? true : false
        })
        this.disable();
    }

    handleNameChange(event) {
        this.employee.name = event.target.value
        this.setState({
            employee: this.employee,
            nameError: (this.employee.name === "") ? true : false
        })
        this.disable();
    }

    handleAddressChange(event) {
        this.employee.address = event.target.value
        this.setState({
            employee: this.employee,
            addressError: (this.employee.address === "") ? true : false
        })
        this.disable();
    }

    handlePhoneChange(event) {
        this.employee.phone = event.target.value
        this.setState({
            employee: this.employee,
            phonenumberError: (this.employee.phone === "") ? true : false,
            numberValidationError: (this.employee.phone.length < 10) ? true : false
        })
        this.disable();
    }

    handleGenderChange(event) {
        this.employee.gender = event.target.value
        this.setState({
            employee: this.employee
        })
        this.disable();
    }

    handleAgeChange(event) {
        this.employee.age = event.target.value
        this.setState({
            employee: this.employee,
            ageError: (this.employee.age === "") ? true : false,
            agelimitError: (this.employee.age >= 100) ? true : false

        })
    }
    disable() {
        this.setState({
            disabledFlag: (this.state.employee.name === "" || this.state.employee.email === "" || this.state.employee.age === "" || this.state.employee.phoneNumber === "" || this.state.employee.gender === "" || this.state.employee.address === "") ? true : false
        })
    }

    render() {
        return (
            <div>
                <form onSubmit={(event) => this.handleSubmit(event)}>
                    <fieldset>
                        <div className="form-group">
                            <label>Email</label>
                            <input type="text" className="form-control" placeholder="Enter email" value={this.state.employee.email} onChange={(event) => this.handleEmailChange(event)} />
                            {
                                (this.state.emailError) ?
                                    <div className="alert alert-danger" role="alert">
                                        Email can't be empty
                        </div> : null
                            }
                        </div>
                        <div className="form-group">
                            <label>Name</label>
                            <input type="text" className="form-control" placeholder="Enter name" value={this.state.employee.name} onChange={(event) => this.handleNameChange(event)} />
                            {
                                (this.state.nameError) ?
                                    <div className="alert alert-danger" role="alert">
                                        Name can't be empty
                        </div> : null
                            }

                        </div>
                        <div className="form-group">
                            <label>Address</label>
                            <textarea className="form-control" placeholder="Enter address" value={this.state.employee.address} onChange={(event) => this.handleAddressChange(event)} rows="3" />
                            {
                                (this.state.addressError) ?
                                    <div className="alert alert-danger" role="alert">
                                        Address can't be empty
                        </div> : null
                            }

                        </div>
                        <div className="form-group">
                            <label>Phone No.</label>
                            <input type="text" className="form-control" placeholder="Enter phone no." value={this.state.employee.phone} onChange={(event) => this.handlePhoneChange(event)} />
                            {
                                (this.state.phonenumberError) ?
                                    <div className="alert alert-danger" role="alert">
                                        Phone number can't be empty
                                    </div> :

                                    (this.state.numberValidationError) ?
                                        <div className="alert alert-danger" role="alert">
                                            Invalid Phone number
                                    </div> : null
                            }
                        </div>
                        <div className="form-group">
                            <label>Age</label>
                            <input type="text" className="form-control" placeholder="Enter age" onChange={(event) => this.handleAgeChange(event)} value={this.state.employee.age} />
                            {
                                (this.state.ageError) ?
                                    <div className="alert alert-danger" role="alert">
                                        Age can't be empty
                        </div> : null
                            }
                            {
                                (this.state.agelimitError) ?
                                    <div className="alert alert-danger" role="alert">
                                        Age should be less than 100
                            </div> : null
                            }

                        </div>
                        <div className="form-group mb-2">
                            <label>Gender</label>
                        </div>
                        <div className="form-group">
                            <div className="form-check form-check-inline">
                                <input className="form-check-input" type="radio" name="inlineRadioOptions" onChange={(event) => this.handleGenderChange(event)} value="Male" checked={this.state.employee.gender === "Male"} />
                                <label className="form-check-label" >Male</label>
                            </div>

                            <div className="form-check form-check-inline">
                                <input className="form-check-input" type="radio" name="inlineRadioOptions" onChange={(event) => this.handleGenderChange(event)} value="Female" checked={this.state.employee.gender === "Female"} />
                                <label className="form-check-label">Female</label>
                            </div>
                        </div>
                        <button type="submit" className="btn btn-secondary" disabled={this.state.disabledFlag}>Submit</button>
                    </fieldset>
                </form>
                {
                    (this.state.successFlag && this.props.employee === undefined) ?
                        <div className="alert alert-success mt-3" role="alert">
                            Employee added successfully.
                        </div>
                        : null
                }

                {
                    (this.state.successFlag && this.props.employee !== undefined) ?
                        <div className="alert alert-success mt-3" role="alert">
                            Employee updated successfully.
                        </div>
                        : null
                }
            </div>
        );
    }
}



export default EmployeeForm;