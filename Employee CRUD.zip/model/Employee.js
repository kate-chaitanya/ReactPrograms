class Employee {
    id
    name
    email
    phone
    address
    gender
    age

    constructor() {
        this.id = 0
        this.name = ""
        this.email = ""
        this.phone = ""
        this.address = ""
        this.gender = ""
        this.age = 0
    }

}
export default Employee
